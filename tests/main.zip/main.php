<?php

use app\widgets\Alert;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\SiteAsset;
use yii\helpers\Html;


/* @var $this \yii\web\View */
/* @var $content string */

SiteAsset::register($this);
?>
<?php $this->beginContent('@app/views/layouts/layout.php'); ?>

<header id="Header">
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">

        <?php
        NavBar::begin([
            'brandLabel' => '',
            'brandUrl' => Yii::$app->homeUrl,
            'options' => [
                'class' => 'navbar-header',
            ],
        ]);
        echo Nav::widget([
            'options' => ['class' => 'nav navbar-nav'],
            'items' => [
                ['label' => 'Главная', 'url' => [Yii::$app->homeUrl],['class' => 'first active']],
                ['label' => 'Услуги', 'url' => ['/main/contact/index'], 'items'=>[
                    ['label' => 'Массаж', 'url' => ['product/index', 'tag' => 'new']],
                    ['label' => 'Перманентный макияж', 'url' => ['product/index', 'tag' => 'popular']],
                ]],
                ['label' => 'Галерея', 'url' => ['/main/contact/index'], 'items'=>[
                    ['label' => 'Веки', 'url' => ['product/index', 'tag' => 'new']],
                    ['label' => 'Брови', 'url' => ['product/index', 'tag' => 'popular']],
                    ['label' => 'Ресницы', 'url' => ['product/index', 'tag' => 'new']],
                    ['label' => 'Губы', 'url' => ['product/index', 'tag' => 'popular']],
                ]],
                ['label' => 'Контакты', 'url' => ['/main/contact/index']],
                ['label' => 'Акции', 'url' => ['/main/contact/index']],
                ['label' => 'Прайс', 'url' => ['/main/contact/index']],
                ['label' => 'Что нужно знать', 'url' => ['/main/contact/index'], 'items'=>[
                    ['label' => 'О нас', 'url' => ['product/index', 'tag' => 'new']],
                    ['label' => 'Почему мы?', 'url' => ['product/index', 'tag' => 'popular']],
                    ['label' => 'Противопоказания', 'url' => ['product/index', 'tag' => 'popular']],
                ]],
            ],

        ]);
        NavBar::end();
        ?>
    </div>
</div>

    <div class="container-fluid">
        <div class="row top-block-wrapper">
            <div class="container">
                <div class="row">
                    <div class="top-block">
                        <div class="col-md-5">
                            <h1 class="title-header">«Совершенство»<small>Студия перманентного макияжа в Тольятти</small></h1>
                        </div>
                        <div class="col-md-7 hidden-xs hidden-sm">
                            <div class="blockText-header col-md-6">
                                <div class="text-header">Оставьте заявку прямо сейчас и получите в подарок <span>массаж лица</span></div>
                                <img src="pic/arrow.png" alt="">
                            </div>
                            <div class="col-md-6">

                                <?=
                                Html::beginForm([Yii::$app->homeUrl], 'post', ['class'=>"form-sidebar"]),
                                Html::tag('h4', 'Оставить заявку', ['class' => 'text-center title-form-sidebar']),
                                Html::input('hidden', 'nospam:blank',""),
                                Html::input('text', 'name',"", ['placeholder'=>"Ваше имя", 'class' => 'form-control','required'=>""]),
                                Html::input('text', 'phone',"", ['placeholder'=>"Ваш номер", 'class' => 'form-control','required'=>""]),
                                Html::button('Получить подарок', ['class' => 'btn btn-record', 'onclick'=>"yaCounter36087230.reachGoal('first_visit'); return true;"]),
                                Html::endForm()
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</header>


    <div class="main container-fluid">

        <div class="row wraper-services">
            <div class="container">
                <h1 class="text-center">Что мы предлагаем</h1>
                <div class="col-md-6 col-sm-6 services-link">
                    <div class="massage">
                        <span>Массаж</span>
                        <div class="btn-hover-services">
                            <button class="btn link-record" data-toggle="modal" data-target="#modal-massage">Записатьcя</button>
                            <button class="btn link-record" data-toggle="modal" data-target="#modal-consultation">Консультация</button>
                            <a href="http://sovtlt.ru/массаж.html" class="btn link-page">Подробнее</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 services-link">
                    <div class="pm">
                        <span>Перманентный макияж</span>
                        <div class="btn-hover-services">
                            <button class="btn link-record" data-toggle="modal" data-target="#modal-pm">Записатьcя</button>
                            <button class="btn link-record" data-toggle="modal" data-target="#modal-consultationPM">Консультация</button>
                            <a href="http://sovtlt.ru/перманентный-макияж.html" class="btn link-page">Подробнее</a>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="modal-massage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <h4 class="modal-title" id="myModalLabel">Запись на массаж</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">


                                    <div class="footerFormWrapper">
                                        <form action="http://sovtlt.ru/" method="post" class="footerForm form-modal">
                                            <div class="col-md-12 col-sm-12">
                                                <p>
                                                </p><h4 class="text-center">Чтобы записаться на прием к специалисту, оставьте заявку <small>Наш администратор свяжется с вами</small></h4>
                                                <p></p>
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="nospam:blank" value="" type="hidden">
                                                <input name="name" value="" class="form-control col-md-4" placeholder="Ваше имя" required="" type="text">
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="phone" id="phone" value="" class="form-control col-md-4" placeholder="Ваш телефон" required="" type="text">
                                            </div>
                                            <div class="col-md-12 col-sm-12"><button class="btn" onclick="yaCounter36087230.reachGoal('recording_massage'); return true;">Отправить</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="modal-pm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <h4 class="modal-title" id="myModalLabel">Запись на перманентный макияж</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">


                                    <div class="footerFormWrapper">
                                        <form action="http://sovtlt.ru/" method="post" class="footerForm form-modal">
                                            <div class="col-md-12 col-sm-12">
                                                <p>
                                                </p><h4 class="text-center">Чтобы записаться на прием к специалисту, оставьте заявку <small>Наш администратор свяжется с вами</small></h4>
                                                <p></p>
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="nospam:blank" value="" type="hidden">
                                                <input name="name" value="" class="form-control col-md-4" placeholder="Ваше имя" required="" type="text">
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="phone" id="phone" value="" class="form-control col-md-4" placeholder="Ваш телефон" required="" type="text">
                                            </div>
                                            <div class="col-md-12 col-sm-12"><button class="btn" onclick="yaCounter36087230.reachGoal('recording_pm'); return true;">Отправить</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="modal-consultation" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <h4 class="modal-title" id="myModalLabel">Записаться на консультацию</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">


                                    <div class="footerFormWrapper">
                                        <form action="http://sovtlt.ru/" method="post" class="footerForm form-modal">
                                            <div class="col-md-12 col-sm-12">
                                                <p>
                                                </p><h4 class="text-center">Чтобы получить консультацию массажиста, оставьте заявку <small>Наш администратор свяжется с вами</small></h4>
                                                <p></p>
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="nospam:blank" value="" type="hidden">
                                                <input name="name" value="" class="form-control col-md-4" placeholder="Ваше имя" required="" type="text">
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="phone" id="phone" value="" class="form-control col-md-4" placeholder="Ваш телефон" required="" type="text">
                                            </div>
                                            <div class="col-md-12 col-sm-12"><button class="btn" onclick="yaCounter36087230.reachGoal('consultation_massage'); return true;">Отправить</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="modal-consultationPM" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <h4 class="modal-title" id="myModalLabel">Записаться на консультацию</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">


                                    <div class="footerFormWrapper">
                                        <form action="http://sovtlt.ru/" method="post" class="footerForm form-modal">
                                            <div class="col-md-12 col-sm-12">
                                                <p>
                                                </p><h4 class="text-center">Чтобы получить консультацию специалиста по татуажу, оставьте заявку <small>Наш администратор свяжется с вами</small></h4>
                                                <p></p>
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="nospam:blank" value="" type="hidden">
                                                <input name="name" value="" class="form-control col-md-4" placeholder="Ваше имя" required="" type="text">
                                            </div>
                                            <div class="col-md-6 col-md-offset-3 col-sm-12">
                                                <input name="phone" id="phone" value="" class="form-control col-md-4" placeholder="Ваш телефон" required="" type="text">
                                            </div>
                                            <div class="col-md-12 col-sm-12"><button class="btn" onclick="yaCounter36087230.reachGoal('сonsultation_pm'); return true;">Отправить</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row about-wrapper">
            <div class="container">
                <div class="col-md-12 title-about"><h1>Почему люди выбирают нас?</h1></div>

                <div class="col-md-3 col-sm-6">
                    <div class="block-about">
                        <div class="pic-1"></div>
                        <div class="title">Опытные мастера</div>
                        <div class="text">более 5 лет работы в этой сфере</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="block-about">
                        <div class="pic-2"></div>
                        <div class="title">Долгосрочный результат</div>
                        <div class="text">гарантируем длительность носки татуажа</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="block-about">
                        <div class="pic-3"></div>
                        <div class="title">Реальное портфолио</div>
                        <div class="text">на сайте представлены только наши работы</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="block-about">
                        <div class="pic-4"></div>
                        <div class="title">Эффективная анестезия</div>
                        <div class="text">дискомфорт при проведении процедуры сводится к минимуму</div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row post-vk">
            <div class="container">
                <h1 class="text-center">Новости группы</h1>
                <div class="col-md-6">
                    <div id="vk_post_-45709848_547" style="height: 694.5px; width: 100%; background: transparent none repeat scroll 0% 0%;"><iframe name="fXDdb128" src="https://vk.com/widget_post.php?app=0&amp;width=100%&amp;_ver=1&amp;owner_id=-45709848&amp;post_id=547&amp;hash=PIqUujmrIzZoqu-5AJSXsRtNWj32&amp;width=500&amp;url=http%3A%2F%2Fwww.sovtlt.ru%2F&amp;referrer=http%3A%2F%2Fsovtlt.ru%2F%25D0%25BA%25D0%25BE%25D0%25BD%25D1%2582%25D0%25B0%25D0%25BA%25D1%2582%25D1%258B&amp;title=%D0%A1%D1%82%D1%83%D0%B4%D0%B8%D1%8F%20%D0%BF%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D0%B5%D0%BD%D1%82%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BC%D0%B0%D0%BA%D0%B8%D1%8F%D0%B6%D0%B0%20%D0%B2%20%D0%A2%D0%BE%D0%BB%D1%8C%D1%8F%D1%82%D1%82%D0%B8%20-%20%D0%A1%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B5%D0%BD%D1%81%D1%82%D0%B2%D0%BE&amp;15877b09755" scrolling="no" id="vkwidget2" style="overflow: hidden; height: 694.5px;" width="100%" height="90" frameborder="0"></iframe></div>

                </div>
                <div class="col-md-6">
                    <div id="vk_post_-45709848_545" style="height: 672px; width: 100%; background: transparent none repeat scroll 0% 0%;"><iframe name="fXD93cf3" src="https://vk.com/widget_post.php?app=0&amp;width=100%&amp;_ver=1&amp;owner_id=-45709848&amp;post_id=545&amp;hash=W-pOdYj2bKnJbFVOx0monHyaTRiC&amp;width=500&amp;url=http%3A%2F%2Fwww.sovtlt.ru%2F&amp;referrer=http%3A%2F%2Fsovtlt.ru%2F%25D0%25BA%25D0%25BE%25D0%25BD%25D1%2582%25D0%25B0%25D0%25BA%25D1%2582%25D1%258B&amp;title=%D0%A1%D1%82%D1%83%D0%B4%D0%B8%D1%8F%20%D0%BF%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D0%B5%D0%BD%D1%82%D0%BD%D0%BE%D0%B3%D0%BE%20%D0%BC%D0%B0%D0%BA%D0%B8%D1%8F%D0%B6%D0%B0%20%D0%B2%20%D0%A2%D0%BE%D0%BB%D1%8C%D1%8F%D1%82%D1%82%D0%B8%20-%20%D0%A1%D0%BE%D0%B2%D0%B5%D1%80%D1%88%D0%B5%D0%BD%D1%81%D1%82%D0%B2%D0%BE&amp;15877b0978e" scrolling="no" id="vkwidget3" style="overflow: hidden; height: 672px;" width="100%" height="90" frameborder="0"></iframe></div>

                </div>
            </div>
        </div>


    </div>



<div class="footer">
    <div class="container">
        <div class="row">
            <h1 class="text-center">Записаться на прием</h1>
            <hr>
            <div class="col-md-6 col-sm-6 col-xs-12">


                <div class="footerFormWrapper row">

                    <form action="http://sovtlt.ru/" method="post" class="footerForm">
                        <div class="col-md-6">
                            <input name="nospam:blank" value="" type="hidden">
                            <span class="error"></span>
                            <input name="name" value="" class="form-control col-md-4" placeholder="Ваше имя" type="text">
                        </div>
                        <div class="col-md-6">
                            <span class="error"></span>
                            <input name="phone" id="phone" value="" class="form-control col-md-4" placeholder="Телефон" type="text">
                        </div>
                        <div class="col-md-12">
                            <span class="error"></span>
                            <textarea name="text" id="text" rows="6" value="" class="form-control" placeholder="Комментарий"></textarea>
                        </div>
                        <div class="col-md-4 col-md-offset-8">
                            <button class="btn btn-record">Отправить</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div id="map">

                </div>
            <div class="col-md-3 contacts-f">


            </div>
        </div>

        <div class="row map-link">
            <ul>
                <p>Информация</p>
                <li><a href="контакты">Контакты</a></li>
                <li><a href="акции">Акции</a></li>
                <li><a href="прайс">Прайс</a></li>
            </ul>
            <ul>
                <p>Услуги</p>
                <li><a href="/перманентный-макияж">Перманентный макияж</a></li>
                <li><a href="/массаж">Массаж</a></li>
            </ul>
            <ul>
                <p>Что нужно знать</p>
                <li><a href="о-нас">О нас</a></li>
                <li><a href="почему-мы">Почему мы?</a></li>
                <li><a href="противопоказания">Противопоказания</a></li>
            </ul>
            <ul>
                <p>Галерея</p>
                <li><a href="веки">Веки</a></li>
                <li><a href="брови">Брови</a></li>
                <li><a href="ресницы">Ресницы</a></li>
                <li><a href="губы">Губы</a></li>
            </ul>
        </div>
        <div class="row contacts-f">
            <p class="name">Совершенство <span class="glyphicon glyphicon-copyright-mark"></span> <?= date('Y') ?></p>
            <p class="adress"><span class="glyphicon glyphicon-map-marker"></span> г. Тольятти, ул. Гагарина 6, офис 102</p>
            <p class="number"><span class="glyphicon glyphicon-earphone"></span> +7(9297) <span>168-777</span></p>
            <p>
                <a href="//www.liveinternet.ru/click" target="_blank"><img src="//counter.yadro.ru/hit?t44.1;rhttp%3A//sovtlt.ru/%25D0%25BA%25D0%25BE%25D0%25BD%25D1%2582%25D0%25B0%25D0%25BA%25D1%2582%25D1%258B;s1366*768*24;uhttp%3A//www.sovtlt.ru/;0.1457402623432349" alt="" title="LiveInternet" width="31" height="31" border="0"></a><!--/LiveInternet-->
            </p>
        </div>

    </div>
</div>

<div class="alert-container container">
    <?= Alert::widget() ?>
</div>

<?php $this->endContent(); ?>
