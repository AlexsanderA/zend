<?php

use yii\helpers\Html;
use app\widgets\BodyClass;
use app\modules\admin\rbac\Rbac as AdminRbac;

/* @var $this \yii\web\View */
/* @var $content string */

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title>Студия перманентного макияжа в Тольятти - Совершенство</title>
    <?php $this->head() ?>
    <script src="//api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
    <script type="text/javascript">
        var myMap;

        // Дождёмся загрузки API и готовности DOM.
        ymaps.ready(init);

        function init () {
            // Создание экземпляра карты и его привязка к контейнеру с
            // заданным id ("map").
            myMap = new ymaps.Map('map', {
                // При инициализации карты обязательно нужно указать
                // её центр и коэффициент масштабирования.
                center: [53.51147728519752,49.41738349999998],
                zoom: 16,
                controls: []
            });
            sov = new ymaps.Placemark([53.51147728519752,49.41738349999998], {
                hintContent: 'Салон «Совершенство»'
            });

            myMap.geoObjects.add(sov);
        }
    </script>
    <style type="text/css" media="screen" id="less:assets-templates-bootstrap-css-main">html {
            position: relative;
            min-height: 100%;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background: #f1f1f1;
            margin-bottom: 0;
        }
        .box,
        .top-block .vk-link,
        .top-contact,
        .title-about h1,
        .block-about,
        .services .services-block,
        .page-contact,
        .shares .shares-block,
        .about-page .about-pic,
        .thank-page,
        .form-sidebar {
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
            -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .nav li:hover {
            background: rgba(0, 0, 0, 0.5);
        }
        .navbar-inverse {
            background-image: linear-gradient(to right, #f7c9cb, #8da3cf);
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-inverse .navbar-nav > li > a {
            color: #353535;
        }
        .navbar-inverse .navbar-nav > .active > a,
        .navbar-inverse .navbar-nav > .active > a:focus,
        .navbar-inverse .navbar-nav > .active > a:hover {
            background: rgba(0, 0, 0, 0.5);
        }
        code {
            font-size: 80%;
        }

        .breadcrumb-wrapper {
            background: #f1f1f1;
        }
        .breadcrumb {
            margin-bottom: 0;
            background: none;
            margin-top: 51px;
            padding-top: 30px;
        }
        .breadcrumb li > a:hover {
            text-decoration: none;
        }
        .breadcrumb li > a:focus {
            text-decoration: none;
        }
        .btn-record {
            background: #86594c;
            color: white;
            -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -webkit-transition: background 200ms, box-shadow 200ms, color 200ms;
            -moz-transition: background 200ms, box-shadow 200ms, color 200ms;
            -o-transition: background 200ms, box-shadow 200ms, color 200ms;
            transition: background 200ms, box-shadow 200ms, color 200ms;
        }
        .btn-record:hover {
            color: #f1f1f1;
            background: #906356;
            -webkit-box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
        }
        .underline-link,
        .breadcrumb li > a {
            border-bottom: 1px solid rgba(51, 122, 183, 0.3);
            -webkit-transition: border-bottom, 200ms;
            -moz-transition: border-bottom, 200ms;
            -o-transition: border-bottom, 200ms;
            transition: border-bottom, 200ms;
        }
        .underline-link:hover {
            border-bottom: 1px solid rgba(51, 122, 183, 0.5);
        }
        .top-block-wrapper {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/fon.jpg") center no-repeat;
            padding-top: 50px;
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .top-block {
            height: 250px;
            position: relative;
            padding-top: 25px;
        }
        .top-block .title-header {
            color: white;
            text-shadow: 0 2px 3px rgba(0, 0, 0, 0.5);
            margin-top: 0;
        }
        @media (max-width: 768px) {
            .top-block .title-header {
                text-align: center;
            }
        }
        .top-block .title-header small {
            display: block;
            margin-top: 10px;
            color: white;
            line-height: 1.2em;
            font-size: 60%;
        }
        .top-block .vk-link {
            padding: 7px 0 7px 40px;
            margin-top: 15px;
            background: url(http://www.sovtlt.ru/assets/templates/bootstrap/pic/vk.png) no-repeat 5px center, rgba(250, 250, 250, 0.95);
        }
        .top-block .form-sidebar {
            margin-top: 0;
        }
        .top-block .blockText-header {
            font-size: 18px;
            color: white;
            font-weight: 300;
            position: relative;
        }
        .top-block .blockText-header .text-header {
            padding-top: 15%;
        }
        .top-block .blockText-header span {
            font-weight: 400;
        }
        .top-block .blockText-header img {
            float: right;
            margin-top: 7px;
        }
        .top-contact {
            margin-top: 50px;
            padding-top: 18px;
            padding-bottom: 8px;
            text-align: center;
            font-size: 17px;
            background: rgba(250, 250, 250, 0.85);
        }
        .top-contact p {
            padding: 0;
        }
        .top-contact .number {
            font-size: 25px;
        }
        .top-contact .number span {
            color: #a24d49;
        }
        .top-contact .btn-num a {
            background: #86594c;
            display: inline-block;
            color: white;
            padding-top: 3px;
            padding-bottom: 3px;
        }
        .top-contact .btn-num a:hover {
            cursor: pointer;
        }
        .nav-top {
            position: relative;
            padding-top: 70px;
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .nav-top .navbar-top {
            display: none;
            position: fixed;
            height: 70px;
            padding-top: 7px;
            top: 0;
            left: 0;
            right: 0;
            z-index: 99999;
            background: -webkit-gradient(linear, from(#FFCCCC), to(#ecb9ba));
            background: -moz-linear-gradient(top, #FFCCCC, #ecb9ba);
            background: linear-gradient(to bottom, #FFCCCC, #ecb9ba);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='@start', endColorstr='@end', GradientType=0);
            -webkit-box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            -moz-box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        .nav-top div,
        .nav-top nav {
            vertical-align: top;
        }
        .nav-top .logo {
            width: 300px;
            height: 50px;
            margin-left: 15px;
            margin-top: 5px;
            display: inline-block;
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/logo.png") no-repeat;
        }
        .nav-top nav {
            display: inline-block;
        }
        .nav-top nav ul li {
            color: #54355e;
            list-style: none;
            display: inline-block;
            padding: 15px;
        }
        .navbar-brand {
            width: 177px;
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/logo.png") no-repeat center;
        }
        .wraper-services {
            padding-bottom: 60px;
        }
        .wraper-services h1 {
            margin-top: 30px;
            margin-bottom: 30px;
        }
        .wraper-services .services-link {
            position: relative;
        }
        .wraper-services .services-link:hover {
            text-decoration: none;
        }
        .wraper-services .services-link:hover span {
            background: rgba(0, 0, 0, 0.45);
        }
        @media (max-width: 768px) {
            .wraper-services .services-link {
                margin-top: 15px;
            }
        }
        .wraper-services .services-link span {
            height: 100%;
            font-size: 28px;
            color: white;
            padding-top: 30px;
            padding-left: 30px;
            display: block;
            background: rgba(0, 0, 0, 0.3);
            text-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
            -webkit-transition: background, 250ms;
            -moz-transition: background, 250ms;
            -o-transition: background, 250ms;
            transition: background, 250ms;
        }
        .block-services,
        .massage,
        .pm {
            height: 300px;
            position: relative;
        }
        .btn-hover-services {
            position: absolute;
            color: white;
            padding-right: 15px;
            padding-left: 15px;
            padding-bottom: 15px;
            bottom: 0;
            width: 100%;
            -webkit-transition: opacity, 200ms;
            -moz-transition: opacity, 200ms;
            -o-transition: opacity, 200ms;
            transition: opacity, 200ms;
        }
        .btn-hover-services a {
            margin-left: 7px;
            float: right;
        }
        .btn-hover-services .link-page,
        .btn-hover-services .link-record {
            color: white;
            -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -webkit-transition: background, 200ms;
            -moz-transition: background, 200ms;
            -o-transition: background, 200ms;
            transition: background, 200ms;
        }
        .btn-hover-services .link-page:hover,
        .btn-hover-services .link-record:hover {
            color: #f1f1f1;
            -webkit-box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 4px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-hover-services .link-page {
            background: #c99789;
        }
        .btn-hover-services .link-page:hover {
            background: #d3a193;
        }
        .btn-hover-services .link-record {
            background: #86594c;
        }
        .btn-hover-services .link-record:hover {
            background: #906356;
        }
        .massage {
            background: url(http://sovtlt.ru/pic/massage.jpg) center;
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .pm {
            background: url(http://sovtlt.ru/pic/pm.jpg) center;
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .va-title {
            color: white;
            margin-top: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2), 0 1px 0 rgba(0, 0, 0, 0.2), 2px 0 0 rgba(0, 0, 0, 0.15);
        }
        .va-slice {
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .va-slice p {
            color: white;
        }
        .va-slice ul {
            margin: 0;
        }
        .va-slice ul li {
            list-style: none;
        }
        .va-slice ul li a:hover {
            text-decoration: none;
        }
        .about-wrapper {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/bg-about.png");
            padding-bottom: 50px;
        }
        .title-about {
            text-align: center;
        }
        .title-about h1 {
            display: inline-block;
            width: 580px;
            color: #555;
            font-size: 32px;
            background: #f2dede;
            padding: 12px 15px;
            margin-top: -20px;
        }
        @media (max-width: 768px) {
            .title-about h1 {
                width: auto;
                font-size: 20px;
            }
        }
        .pic-about,
        .block-about .pic-1,
        .block-about .pic-2,
        .block-about .pic-3,
        .block-about .pic-4 {
            width: 100%;
            height: 150px;
        }
        .block-about {
            position: relative;
            text-align: center;
            background: rgba(250, 250, 250, 0.75);
            padding: 0 15px 0 15px;
            height: 300px;
            margin-top: 30px;
        }
        .block-about .pic-1 {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/about-1.png") no-repeat center;
        }
        .block-about .pic-2 {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/about-2.png") no-repeat center;
        }
        .block-about .pic-3 {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/about-3.png") no-repeat center;
        }
        .block-about .pic-4 {
            background: url("http://www.sovtlt.ru/assets/templates/bootstrap/pic/about-4.png") no-repeat center;
        }
        .block-about .title {
            font-size: 19px;
            margin-bottom: 15px;
            color: #86594c;
        }
        .post-vk {
            padding-top: 35px;
            padding-bottom: 50px;
        }
        .post-vk h1 {
            margin-top: 0;
            margin-bottom: 25px;
        }
        .footer {
            width: 100%;
            padding-top: 35px;
            padding-bottom: 35px;
            background-color: #111;
            height: auto;
        }
        .footer .text-muted {
            margin: 20px 0;
        }
        .footer input,
        .footer textarea {
            background: #f1f1f1;
        }
        .footer textarea {
            margin-top: 15px;
            resize: none;
        }
        .footer h1 {
            color: #f1f1f1;
            margin-bottom: 15px;
        }
        .footer hr {
            width: 50px;
            margin: 15px auto 40px auto;
        }
        .footer #map {
            height: 263px;
        }
        @media (max-width: 768px) {
            .footer #map {
                margin-top: 50px;
            }
        }
        .footer .btn {
            margin-top: 15px;
            background: #a24d49;
            color: white;
            float: right;
        }
        .footer span.error {
            color: white;
        }
        .contacts-f {
            margin-top: 15px;
            text-align: center;
        }
        .contacts-f .number,
        .contacts-f .adress,
        .contacts-f .name {
            color: #f1f1f1;
            margin: 0;
        }
        .contacts-f .number {
            margin-bottom: 5px;
            margin-top: 3px;
        }
        .contacts-f .name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .contacts-f .name span {
            font-weight: 300;
        }
        .footerForm .form-control {
            margin-top: 7px;
        }
        .map-link ul {
            display: inline-block;
            vertical-align: top;
        }
        .map-link p {
            color: white;
            font-size: 18px;
            margin-top: 15px;
        }
        .map-link li {
            list-style: none;
            padding-left: 5px;
            margin-top: 3px;
        }
        .map-link li a {
            color: #ccc;
            border-bottom: 1px solid rgba(204, 204, 204, 0.3);
            -webkit-transition: border-bottom, 200ms;
            -moz-transition: border-bottom, 200ms;
            -o-transition: border-bottom, 200ms;
            transition: border-bottom, 200ms;
        }
        .map-link li a:hover {
            border-bottom: 1px solid rgba(204, 204, 204, 0.5);
            text-decoration: none;
        }
        .map-link li a:focus {
            text-decoration: none;
        }
        .header-services {
            position: relative;
            margin-top: 15px;
        }
        .header-services .header-services-wrapper {
            overflow: hidden;
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
        }
        .header-services .header-services-wrapper img {
            width: 100%;
        }
        .header-services h1 {
            color: white;
            width: 100%;
            padding-right: 15px;
            padding-left: 15px;
            text-align: center;
            position: absolute;
            top: 71px;
            vertical-align: middle;
            text-shadow: 0 1px 3px rgba(0, 0, 0, 0.5);
        }
        .header-wrapper {
            font-size: 17px;
            font-weight: 300;
            margin-bottom: 50px;
            padding-bottom: 15px;
            padding-top: 7px;
        }
        .header-wrapper h1 {
            font-weight: 400;
        }
        .services {
            color: #333;
            padding-bottom: 30px;
        }
        .services .collapsed h4 {
            background: url(http://www.sovtlt.ru/assets/templates/bootstrap/pic/arrow.png) no-repeat center right;
        }
        .services .services-block {
            background: white;
            padding: 4px 15px;
            margin-bottom: 20px;
        }
        .services .services-block h4 {
            font-weight: 400;
            padding-right: 30px;
            line-height: 1.5em;
        }
        .services .services-block p {
            line-height: 1.5em;
            font-size: 16px;
        }
        .services .services-block p:first-child {
            margin-top: 10px;
        }
        .services .services-block div {
            padding-top: 7px;
            border-top: 1px solid #ddd;
        }
        .services .services-block kbd {
            background: #D9EDF7;
            color: black;
            font-size: 17px;
        }
        @media (max-width: 768px) {
            .services .services-block kbd {
                margin-top: 7px;
                margin-left: 0;
            }
        }
        .services .services-block .btn {
            margin-top: 15px;
            margin-bottom: 15px;
            display: block;
            background: #86594c;
            color: white;
        }
        .services .services-block .price {
            margin-left: 7px;
            background: rgba(255, 235, 59, 0.35);
        }
        .page-contact {
            margin-top: 70px;
            margin-bottom: 50px;
            padding-bottom: 30px;
            background: white;
        }
        .page-contact form {
            margin-top: 0;
        }
        .page-contact form .btn {
            float: right;
        }
        .page-contact input,
        .page-contact textarea {
            background: #f1f1f1;
        }
        .page-contact textarea {
            margin-top: 15px;
            resize: none;
        }
        .page-contact .btn {
            margin-top: 15px;
        }
        .page-contact h1 {
            margin-bottom: 30px;
        }
        .page-contact p {
            padding: 0;
        }
        .page-contact #map {
            height: 350px;
        }
        .page-contact .number {
            font-size: 25px;
        }
        .page-contact .number span {
            color: #a24d49;
        }
        .page-contact .btn-num a {
            background: #86594c;
            display: inline-block;
            color: white;
            padding-top: 3px;
            padding-bottom: 3px;
        }
        .page-contact .btn-num a:hover {
            cursor: pointer;
        }
        .shares-wrapper {
            padding-bottom: 50px;
        }
        .shares-wrapper h1 {
            margin-top: 0;
        }
        .shares-wrapper .panel {
            -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .shares {
            color: #333;
            padding-top: 70px;
        }
        .shares .text-center {
            margin-bottom: 25px;
        }
        .shares .shares-block {
            background: white;
            padding: 12px 15px;
            margin-bottom: 15px;
        }
        .shares img {
            float: left;
            margin-left: 7px;
            margin-right: 30px;
            margin-top: 4px;
        }
        .shares .text-muted {
            margin-top: 0;
        }
        .about-page {
            color: #333;
            font-size: 15px;
            line-height: 1.5em;
            margin-bottom: 50px;
        }
        .about-page h1 {
            font-weight: 400;
        }
        .about-page .about-pic {
            overflow: hidden;
        }
        .about-page .about-pic img {
            width: 100%;
        }
        .gallery-page {
            margin-bottom: 70px;
        }
        .gallery-page h1 {
            margin-bottom: 30px;
        }
        .gallery-link {
            margin-top: 30px;
        }
        .gallery-link .btn-hover-services {
            width: auto;
            position: absolute;
            right: 0;
            padding-right: 30px;
        }
        .block-gallery,
        .eyelids,
        .eyebrows,
        .eyelashes,
        .lips {
            height: 250px;
            -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -moz-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            -webkit-background-size: cover !important;
            background-size: cover !important;
        }
        .eyelids span,
        .eyebrows span,
        .eyelashes span,
        .lips span {
            position: relative;
            display: block;
            width: 100%;
            height: 100%;
            padding-top: 15px;
            padding-left: 15px;
            color: white;
            font-size: 30px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
            -webkit-transition: background, 250ms;
            -moz-transition: background, 250ms;
            -o-transition: background, 250ms;
            transition: background, 250ms;
        }
        .eyelids span:hover,
        .eyebrows span:hover,
        .eyelashes span:hover,
        .lips span:hover {
            background: rgba(0, 0, 0, 0.3);
        }
        .eyelids .snippet-gallery,
        .eyebrows .snippet-gallery,
        .eyelashes .snippet-gallery,
        .lips .snippet-gallery {
            width: 12px;
            height: 250px;
            position: absolute;
            right: 0;
            top: 0;
        }
        .eyelids .snippet-gallery div,
        .eyebrows .snippet-gallery div,
        .eyelashes .snippet-gallery div,
        .lips .snippet-gallery div {
            vertical-align: top;
        }
        .eyelids .snippet-gallery .first,
        .eyebrows .snippet-gallery .first,
        .eyelashes .snippet-gallery .first,
        .lips .snippet-gallery .first {
            width: 4px;
            height: 240px;
            margin-top: 6px;
            background: rgba(0, 0, 0, 0.6);
            display: inline-block;
            position: relative;
            left: -1px;
        }
        .eyelids .snippet-gallery .second,
        .eyebrows .snippet-gallery .second,
        .eyelashes .snippet-gallery .second,
        .lips .snippet-gallery .second {
            width: 4px;
            height: 230px;
            margin-top: 10px;
            background: rgba(0, 0, 0, 0.6);
            display: inline-block;
            position: relative;
            left: -2px;
        }
        .eyelids {
            background: url('/pic/eyelids/1.jpg') no-repeat center;
        }
        .eyebrows {
            background: url('/pic/eyebrows/2.jpg') no-repeat center;
        }
        .eyelashes {
            background: url('/pic/eyelashes/1.jpg') no-repeat center;
        }
        .lips {
            background: url('/pic/lips/1.jpg') no-repeat center;
        }
        .my-gallery {
            width: 100%;
            float: left;
        }
        .my-gallery img {
            width: 100%;
            height: auto;
        }
        .my-gallery figure {
            display: block;
            margin-top: 30px;
            min-height: 250px;
        }
        .my-gallery figcaption {
            display: none;
        }
        .thank-page {
            margin-top: 70px;
            padding-bottom: 15px;
            padding-top: 15px;
            color: #333;
            background: white;
        }
        .thank-page h3 {
            margin-bottom: 0;
            padding-bottom: 5px;
            border-bottom: 1px solid #f1f1f1;
        }
        .thank-page p {
            font-size: 18px;
            margin-top: 7px;
            padding-top: 0;
        }
        .thank-page .btn {
            margin-top: 7px;
        }
        .form-modal .btn {
            display: block;
            width: 100px;
            margin: 15px auto 0 auto;
            background: #86594c;
            color: white;
        }
        .form-modal h4 > small {
            display: block;
            margin-top: 5px;
        }
        .sidebar-article {
            position: relative;
        }
        @media (max-width: 768px) {
            .sidebar-article {
                margin-bottom: 15px;
            }
        }
        .nav-sidebar a {
            display: block;
        }
        .nav-sidebar a:hover {
            text-decoration: none;
        }
        .form-sidebar {
            background: white;
            padding: 10px 15px;
            margin-top: 15px;
            max-width: 255px;
            top: 70px;
            -webkit-transition: width;
            -moz-transition: width;
            -o-transition: width;
            transition: width;
        }
        @media (max-width: 768px) {
            .form-sidebar {
                width: 50%;
                margin: 15px auto 0 auto;
                min-width: 70%;
            }
        }
        .form-sidebar .title-form-sidebar span {
            color: #86594c;
        }
        .form-sidebar input {
            margin-bottom: 10px;
            width: 100%;
        }
        .form-sidebar .btn {
            margin: 7px auto 0 auto;
            display: block;
        }
    </style>
</head>

<?php BodyClass::begin()?>
    <?php $this->beginBody() ?>
        <?= $content ?>



    <?php $this->endBody() ?>
<?php BodyClass::end()?>
</html>
<?php $this->endPage() ?>
