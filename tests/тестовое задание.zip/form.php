<?php

if (isset($_POST["Proizv"])) { 
   
    $Proizv=$_POST["Proizv"];
    $name=$_POST["name"];
    $price=$_POST["price"];
	$kol_vo=$_POST["kol_vo"];
}

$file ="test.txt";
$f_o=fopen($file,"a+") or die("���������� �������/������� ����");
$array=file($file);
 $last_elem = count($array)-1;
 $ouwt = explode("::", $last_elem);
 $last=$ouwt[0]+2;
$stroka=$last."::".$Proizv."::".$name."::".$price."::".$kol_vo;
fwrite($f_o, $stroka. PHP_EOL) or die ('�� �������');

//foreach($array as $string)
//echo $string;
fclose($f_o);

    $val = file( "test.txt" );
    foreach($val as $value)
    {
         $out = explode("::", $value);
         if(!empty($out[1]))
         {
              echo "<br>";
             // echo $out[0]." ";
            //  echo $out[1]." ";
            //  echo $out[2]." ";
            //  echo $out[3]." ";
			//  echo $out[4]." ";
         }
    }
?>