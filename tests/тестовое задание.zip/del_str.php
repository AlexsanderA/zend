<?php
if (isset($_POST["id_str"])) { 
   $str_id = (int)$_POST['id_str'];
     
}


$file = 'test.txt'; 
$list = array();      //для хранения открытого файла

$list = file($file) or die('Не открывается'); 

unset($list[$str_id-1]);


$f = fopen($file, 'w+');
flock($f, LOCK_EX);
foreach($list as $string)
{
        fwrite($f, $string);
}
flock($f, LOCK_UN);
fclose($f); 
?>