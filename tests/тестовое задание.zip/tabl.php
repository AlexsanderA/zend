<table style="text-align: center;" class="spc" border="1" cellspacing="2" cellpadding="2" width="98%">
<Tr>
 <td class="thd" onclick="sort(this)" title="Нажмите на заголовок, чтобы отсортировать колонку">Производитель</td>
 <td class="thd" onclick="sort(this)" title="Нажмите на заголовок, чтобы отсортировать колонку">Наименование</td>
 <td class="thd" onclick="sort(this)" title="Нажмите на заголовок, чтобы отсортировать колонку">Цена</td>
 <td class="thd" onclick="sort(this)" title="Нажмите на заголовок, чтобы отсортировать колонку">Количество</td>
 </tr>
<?php
	$sum_price=0;
	$sum_Kol_vo=0;
	$i=0;
    $val = file( "test.txt" );
    foreach($val as $value)
    {
			
         $out = explode("::", $value);
         if(!empty($out[1]))
         {
			$i++;
		
			  echo "<tr id='".$i."' onclick='del_str(".$i.")' title='".$out[1]." ".$out[2]."' >";
              echo "<td  value='".$out[1]."'>".$out[1]."</td>";
              echo "<td>".$out[2]."</td>";
              echo "<td>".$out[3]."</td>";
			  echo "<td>".$out[4]."</td>";
			  
			  $sum_price=$sum_price+$out[3];
			  $sum_Kol_vo=$sum_Kol_vo+$out[4];
			  echo "</tr>";
         }
    }
	
	?>
	</table>
	<table style="text-align: center;" class="spc" border="0" cellspacing="2" cellpadding="2" width="98%">
	 <Tr>
 <td class="thd" colspan="2" style="text-align: left;"> Итого </td><td class="thd"><?php echo $sum_price; ?></td><td class="thd"><?php echo $sum_Kol_vo; ?></td>
 </tr>
	</table>